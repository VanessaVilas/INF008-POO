package br.edu.ifba.inf008.grpc;

import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.stub.StreamObserver;

import java.io.IOException;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) throws IOException, InterruptedException {
        Server server = ServerBuilder.forPort(50051)
                .addService(new PersonServiceImpl())
                .build();

        server.start();
        System.out.println("Server started on port 50051");

        server.awaitTermination();
    }

    static class PersonServiceImpl extends PersonServiceGrpc.PersonServiceImplBase {
        @Override
        public void sayHello(Person request, StreamObserver<HelloResponse> responseObserver) {
            String greeting = "Hello " + request.getName();
            System.out.println(greeting);

            HelloResponse response = HelloResponse.newBuilder()
                    .setMessage(greeting)
                    .build();

            responseObserver.onNext(response);
            responseObserver.onCompleted();
        }
    }
}
