package br.edu.ifba.inf008.grpc;

import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.IOException;

import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;

import java.util.concurrent.TimeUnit;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) throws IOException, InterruptedException {
        // Create a new Person
        Person person = Person.newBuilder()
                .setName("Alice")
                .setId(0)
                .setEmail("alice@ifba.edu.br")
                .build();

        // Save to file
        String filename = "person.bin";
        try (FileOutputStream out = new FileOutputStream(filename)) {
            person.writeTo(out);
            System.out.println("Person written to file: " + filename);
        } catch (IOException e) {
            System.err.println("Failed to write person: " + e.getMessage());
        }

        // Read from file
        FileInputStream in = new FileInputStream(filename);
        Person loadedPerson = Person.parseFrom(in);
        System.out.println("Person read from file:");
        System.out.println("Name: " + loadedPerson.getName());
        System.out.println("Id: " + loadedPerson.getId());
        System.out.println("Email: " + loadedPerson.getEmail());

        // Connect to localhost:50051 (make sure it matches your server address)
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost", 50051)
                .usePlaintext() // disable TLS for simplicity
                .build();

        PersonServiceGrpc.PersonServiceBlockingStub stub = PersonServiceGrpc.newBlockingStub(channel);

        try {
            // Call SayHello RPC
            HelloResponse response = stub.sayHello(person);

            System.out.println("Server response: " + response.getMessage());

        } catch (StatusRuntimeException e) {
            System.err.println("RPC failed: " + e.getStatus());
        } finally {
            // Shutdown channel properly
            channel.shutdown().awaitTermination(5, TimeUnit.SECONDS);
        }
    }
}
