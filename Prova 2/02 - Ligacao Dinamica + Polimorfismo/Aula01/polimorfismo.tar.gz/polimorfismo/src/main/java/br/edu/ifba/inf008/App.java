package br.edu.ifba.inf008;

// class A {
//     public void m1();
// }
//
// class B extends A {
//     public void m2();
// }
//
// A a1 = new A();
// a1.m1();
// B b1 = new B();
// b1.m1();
// b1.m2();
//
// A b2 = new B();
// b2.m1(); // SIM
// b2.m2(); // NAO
//
// B b3 = (B) b2; // CASTING
// b3.m1(); // SIM
// b3.m2(); // SIM
// ((B) b2).m2(); // SIM

interface ICredential {
    public boolean isValid();
}

class DatabaseCredential implements ICredential {
    private String username;
    private String password;

    public DatabaseCredential(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public boolean isValid() {
        return !username.isEmpty() && !password.isEmpty();
    }

    public boolean verify(String username, String password) {
        return username == "sandro" && password == "1234";
    }
}

interface IAuthenticator {
    public boolean signIn(ICredential credential);
}

class DatabaseAuthenticator implements IAuthenticator
{
    public boolean signIn(ICredential credential) {
        // Validate whether credential is a DatabaseCredential
        if (!(credential instanceof DatabaseCredential)) {
            return false;
        }
        if (!credential.isValid()) {
            return false;
        }
        DatabaseCredential dbCredential = (DatabaseCredential) credential;
        return dbCredential.verify("sandro", "1234");
    }
}

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
        IAuthenticator authenticator = new DatabaseAuthenticator();
        ICredential credential = new DatabaseCredential("sandro", "1234");
        if (authenticator.signIn(credential)) {
            System.out.println("Authentication successful!");
        } else {
            System.out.println("Authentication error!");
        }
    }
}
